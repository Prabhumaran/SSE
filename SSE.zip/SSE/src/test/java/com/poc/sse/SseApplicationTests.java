package com.poc.sse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SseApplicationTests {

	@Test
	void contextLoads() {
	}

}
