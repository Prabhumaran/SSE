package com.poc.sse.WebFluxConfig;

import org.springframework.web.reactive.config.EnableWebFlux;
import org.springframework.web.reactive.function.client.WebClient;



import reactor.core.publisher.Flux;
import java.time.LocalTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.codec.ServerSentEvent;
@Configuration
@EnableWebFlux
public class WebFluxConfig {
	
	private static final Logger logger = LoggerFactory.getLogger(WebFluxConfig.class);
	
	public void consumeServerSentEvent() {
	    WebClient client = WebClient.create("http://localhost:8080/sse-server");
	    ParameterizedTypeReference<ServerSentEvent<String>> type
	     = new ParameterizedTypeReference<ServerSentEvent<String>>() {};

	    Flux<ServerSentEvent<String>> eventStream = client.get()
	      .uri("/stream-sse")
	      .retrieve()
	      .bodyToFlux(type);

	    eventStream.subscribe(
	      content -> logger.info("Time: {} - event: name[{}], id [{}], content[{}] ",
	        LocalTime.now(), content.event(), content.id(), content.data()),
	      error -> logger.error("Error receiving SSE: {}", error),
	      () -> logger.info("Completed!!!"));
	}

}
