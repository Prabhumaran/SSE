package com.demo.sse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTimeNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
