package com.demo.sse.controller;

import java.time.Duration;
import java.time.LocalTime;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.codec.ServerSentEvent;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import com.demo.sse.config.WebFluxConfig;

import io.netty.handler.timeout.ReadTimeoutException;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class WebClientController {

	private static final Logger logger = LoggerFactory.getLogger(WebClientController.class);
	@Autowired
	WebFluxConfig webFluxConfig;
	
	@GetMapping("/clientApi")
	public void callApi() {
		 ParameterizedTypeReference<ServerSentEvent<String>> type
	     = new ParameterizedTypeReference<ServerSentEvent<String>>() {};
	     Flux<ServerSentEvent<String>> eventStream =	webFluxConfig.getWebClientmeth().get().uri("/subscribe").retrieve().bodyToFlux(type).timeout(Duration.ofSeconds(10_000), Mono.error(new ReadTimeoutException("Timeout")))
	    	     .onErrorContinue((e, i) -> {
	    	         // Log the error here.
	    	     });
		
	     		eventStream.subscribe(
				      content -> logger.info("Time: {} - event: name[{}], id [{}], content[{}] ",
				        LocalTime.now(), content.event(), content.id(), content.data()),
				      error -> logger.error("Error receiving SSE: {}", error),
				      () -> logger.info("Completed!!!"));
				
	}
		
	
}
