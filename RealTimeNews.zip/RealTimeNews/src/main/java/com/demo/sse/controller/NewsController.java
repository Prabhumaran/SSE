package com.demo.sse.controller;


import java.io.IOException;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.json.JSONObject;
import org.springframework.boot.jackson.JsonObjectDeserializer;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@RestController
public class NewsController {

	public List<SseEmitter> emitters = new CopyOnWriteArrayList<>();
	
	@CrossOrigin
	@RequestMapping(value="/subscribe", consumes = MediaType.ALL_VALUE)
	public SseEmitter subscribe() {
		SseEmitter sseEmitter = new SseEmitter(Long.MAX_VALUE);
		try {
		sseEmitter.send(SseEmitter.event().name("INIT"));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		sseEmitter.onCompletion(()->emitters.remove(sseEmitter));
		emitters.add(sseEmitter);
		return sseEmitter;
	}
	
	@PostMapping(value="/dispatchEvent")
	public void dispatchEventToClients(@RequestParam String title,@RequestParam String text) {
		
		String output = new JSONObject().put("title",title).put("text",text).toString();
				
		for(SseEmitter emitter : emitters) {
			try {
				emitter.send(SseEmitter.event().name("latestNews").data(output));
			}catch (IOException ex) {
				emitters.remove(emitter);
			}
		}
	}
	
}
